
const Menu = () => (
    <>
    </>
);

export default Menu;